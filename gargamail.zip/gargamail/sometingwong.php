<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Oops!</title>
    <link rel="stylesheet" href="styles/style_wrong.css">
</head>
<body>
    <div class="main">
        <div class="text">
            Something went wrong!<br>
            Please check if you have:<br>
        </div>
        <div class="reqs">
            <ul>
                <li>entered the correct email address</li>
                <li>entered the correct password</li>
            </ul>
        </div>
        <p><a href="login_front.php">Take me back to login</a></p>
    </div>
</body>
</html>